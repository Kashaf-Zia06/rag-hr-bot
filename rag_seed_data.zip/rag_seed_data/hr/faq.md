# HR Chatbot FAQ (Seed)

- **Q:** How many annual leave days do I have?
  **A:** 24 per year (accrual 2/month). Check your balance in the app.

- **Q:** When is late arrival recorded?
  **A:** After 9:15 AM per Attendance Policy.

- **Q:** Do I need a medical certificate?
  **A:** Yes, for sick leave > 3 consecutive days.

- **Q:** Who approves expenses above PKR 50,000?
  **A:** Director-level approval is required.
