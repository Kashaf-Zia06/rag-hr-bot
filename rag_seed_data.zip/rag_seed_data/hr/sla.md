# SLA Standards

- **Manager Approval**: 2 business days.
- **HR Secondary Approval**: 2 business days.
- **Escalation**: Auto-escalate on SLA breach.
