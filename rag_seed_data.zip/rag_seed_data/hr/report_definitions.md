# Report Definitions

- **Attendance Heatmap**: Density of late arrivals/absences by day.
- **Request Volume**: Count by type/status/department.
- **SLA Compliance**: Avg approval time; % breaches.
