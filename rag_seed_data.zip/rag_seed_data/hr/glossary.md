# Glossary

- **OD**: Official Duty (off-site work, counts as present).
- **SLA**: Service Level Agreement for approvals.
- **TOIL**: Time Off In Lieu.
- **Blackout Dates**: Periods when certain leave types are restricted.
