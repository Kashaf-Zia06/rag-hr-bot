# Expense Policy (v2.0)

- **Categories**: Travel, Meals, Lodging, Supplies.
- **Limits**: Meals <= PKR 2,000/day; Lodging <= PKR 12,000/night; Supplies <= PKR 10,000 per request.
- **Receipts**: Mandatory for claims > PKR 1,000.
- **Approvals**: Manager approval; > PKR 50,000 requires Director.
