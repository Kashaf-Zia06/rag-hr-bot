# Travel Policy (v1.0)

- **Classes**: Domestic Economy; International Economy (Manager+) with justification.
- **Per Diem**: Domestic PKR 2,500/day; International USD 35/day.
- **Advance**: Up to 80% of estimated costs, reconciled within 5 business days post-travel.
