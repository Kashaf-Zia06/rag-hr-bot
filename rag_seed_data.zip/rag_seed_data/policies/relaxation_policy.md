# Policy Relaxations (v1.0)

- HR may grant exceptions (e.g., medical emergencies).
- All relaxations logged with reason and validity dates.
