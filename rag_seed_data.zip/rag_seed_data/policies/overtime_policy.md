# Overtime Policy (v1.0)

- Overtime is pre-approved work beyond scheduled hours.
- Compensated per company rate card or time-off in lieu (TOIL) per manager discretion.
