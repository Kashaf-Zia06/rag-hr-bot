# Transfer Policy (v1.0)

- Inter-department or inter-location transfers allowed per business need.
- Requires consent of both managers and HR approval.
