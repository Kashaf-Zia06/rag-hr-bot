# Resignation Policy (v1.0)

- Minimum notice period: 30 days.
- Exit clearance from IT, Admin, Finance required before F&F settlement.
