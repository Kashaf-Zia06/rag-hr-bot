# Promotion Policy (v1.0)

- Based on performance, skills, and business need.
- Requires Manager recommendation and HR validation.
- Effective from the first day of the next payroll cycle.
