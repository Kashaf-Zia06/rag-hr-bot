import os, argparse, pickle, faiss, numpy as np
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv
from tabulate import tabulate
import json
import textwrap

def call_llm(prompt: str):
    # Select LLM backend using env flags
    from dotenv import load_dotenv
    load_dotenv()
    use_ollama = os.getenv("USE_OLLAMA","0") == "1"
    if use_ollama:
        # Local Ollama
        import requests
        model = os.getenv("OLLAMA_MODEL","llama3.1")
        resp = requests.post("http://localhost:11434/api/generate", json={"model": model, "prompt": prompt})
        out = ""
        for line in resp.iter_lines():
            if not line:
                continue
            chunk = json.loads(line.decode("utf-8"))
            out += chunk.get("response","")
            if chunk.get("done", False):
                break
        return out.strip()
    else:
        # OpenAI
        from openai import OpenAI
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            return "[LLM ERROR] Set OPENAI_API_KEY or enable USE_OLLAMA."
        client = OpenAI(api_key=api_key)
        resp = client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL","gpt-4o-mini"),
            messages=[{"role":"system","content":"You answer using ONLY the provided context. If unknown, say you don't know."},
                      {"role":"user","content": prompt}],
            temperature=0.2,
        )
        return resp.choices[0].message.content

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--index-path", required=True)
    ap.add_argument("--meta-path", default=None)
    ap.add_argument("--question", required=True)
    ap.add_argument("--k", type=int, default=6)
    args = ap.parse_args()

    # Load index + metadata
    index = faiss.read_index(args.index_path)
    meta_path = args.meta_path or (args.index_path + ".meta.pkl")
    with open(meta_path, "rb") as f:
        docs = pickle.load(f)  # list of {text, meta}
    texts = [d["text"] for d in docs]

    # Embed query
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
    qemb = model.encode([args.question], convert_to_numpy=True)
    faiss.normalize_L2(qemb)
    D, I = index.search(qemb, args.k)
    I = I[0]

    # Build context with lightweight dedup by source
    seen = set()
    context_blocks = []
    citations = []
    for idx in I:
        if idx < 0: 
            continue
        src = docs[idx]["meta"].get("source","unknown")
        key = (src,)
        if key in seen: continue
        seen.add(key)
        context_blocks.append(f"[Source: {src}]\n{docs[idx]['text']}")
        citations.append(src)

    context = "\n\n---\n\n".join(context_blocks[:args.k])

    prompt = f"""You are an HR assistant for an internal system.
Answer the user's question using ONLY the following context. Cite the sources by filename in brackets like [source: filename].
If the answer isn't contained in the context, say "I don't know based on the indexed policies/data."

Question: {args.question}

Context:
{context}
"""

    answer = call_llm(prompt)

    print("\n" + "="*80)
    print("QUESTION:")
    print(args.question)
    print("="*80)
    print("ANSWER:")
    print(textwrap.fill(answer, width=100))
    print("="*80)
    print("CITED SOURCES (filenames):")
    print(", ".join(citations))

if __name__ == "__main__":
    main()
